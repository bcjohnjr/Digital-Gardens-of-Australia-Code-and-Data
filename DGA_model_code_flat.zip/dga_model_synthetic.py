"""Digital Gardens Australia: synthetic 16-weather-year hourly dispatch and ledgers.

Run: python dga_model_synthetic.py   (earlier synthetic-weather comparison; all files in this folder)
"""
import sys, json, math, time
import numpy as np
from scipy.signal import lfilter
from scipy.stats import norm

import os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.dont_write_bytecode = True          # keep the folder flat: no __pycache__
sys.path.insert(0, HERE)
import dga_params as P
rng = np.random.default_rng(P.SEED)

NH, H = P.NH, P.NHUB
h = np.arange(NH)
doy = (h // 24) % 365
hr = h % 24
yr = h // P.HPY
shares = np.array([x["share"] for x in P.HUBS])
assert abs(shares.sum() - 1) < 1e-9


def ar1(n, rho, sd=1.0):
    e = rng.standard_normal(n + 2000) * math.sqrt(1 - rho * rho)
    x = lfilter([1.0], [1.0, -rho], e)[2000:]
    return x * sd


# ------------------------------------------------------------------ temperature
mid = np.array([15, 45, 74, 105, 135, 166, 196, 227, 258, 288, 319, 349])
T = np.zeros((H, NH))
for i, hb in enumerate(P.HUBS):
    tm = np.array(hb["tm"])
    xp = np.concatenate([mid - 365, mid, mid + 365])
    fp = np.concatenate([tm, tm, tm])
    clim = np.interp(doy + hr / 24.0, xp, fp)
    diur = hb["amp"] * np.cos(2 * np.pi * (hr - 15) / 24.0)
    syn = ar1(NH, 0.995, 2.5)
    yoff = rng.normal(0, 0.4, P.YEARS)[yr]
    T[i] = clim + diur + syn + yoff

# ------------------------------------------------------------------ solar
season_clear = {  # DJF, MAM, JJA, SON mean clearness
    "QLD": (0.66, 0.78, 0.86, 0.80), "NSW": (0.72, 0.75, 0.78, 0.76),
    "VIC": (0.74, 0.62, 0.55, 0.64), "SA": (0.84, 0.78, 0.70, 0.79), "WA": (0.88, 0.74, 0.60, 0.76)}
month = np.searchsorted(np.cumsum([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]), doy, side="right")
seas = np.select([np.isin(month, [11, 0, 1]), np.isin(month, [2, 3, 4]), np.isin(month, [5, 6, 7])], [0, 1, 2], 3)
nd = P.YEARS * 365
reg_day = {r: ar1(nd, 0.6) for r in ["east", "south", "west"]}
PVraw = np.zeros((H, NH))
for i, hb in enumerate(P.HUBS):
    phi = math.radians(hb["lat"])
    dec = np.radians(23.44) * np.sin(2 * np.pi * (284 + doy) / 365.0)
    om = np.radians(15.0 * (hr + 0.5 - 12.0))
    cosz = np.sin(phi) * np.sin(dec) + np.cos(phi) * np.cos(dec) * np.cos(om)
    cosz = np.clip(cosz, 0, None)
    am = 1.0 / np.maximum(cosz, 0.06)
    dni = np.where(cosz > 0.02, 1353.0 * 0.7 ** (am ** 0.678), 0.0)
    cos_tr = np.sqrt(cosz ** 2 + (np.cos(dec) * np.sin(om)) ** 2)
    m = np.array(season_clear[hb["state"]])[seas]
    zd = 0.6 * reg_day[hb["wind_region"]] + 0.8 * ar1(nd, 0.5)
    kd = np.clip(m + 0.16 * zd[h // 24], 0.08, 1.0)
    kh = np.clip(kd * (1 + 0.06 * rng.standard_normal(NH)), 0.05, 1.05)
    poa = kh * dni * cos_tr + (1.15 - kh) * 140.0 * np.sqrt(cosz)
    tcell = T[i] + 0.03 * poa
    PVraw[i] = np.clip(poa / 1000.0 * (1 - 0.0035 * (tcell - 25.0)), 0, None)

PV = np.zeros((H, NH))
pv_ratio = []
for i, hb in enumerate(P.HUBS):
    lo, hi = 0.3, 4.0
    for _ in range(60):
        r = 0.5 * (lo + hi)
        cf = np.minimum(r * PVraw[i], 1.0).mean() * 0.97
        if cf < hb["pcf"]:
            lo = r
        else:
            hi = r
    PV[i] = np.minimum(r * PVraw[i], 1.0) * 0.97
    pv_ratio.append(r)

# ------------------------------------------------------------------ wind
F_nat = ar1(NH, 0.985)
F_reg = {r: ar1(NH, 0.98) for r in ["east", "south", "west"]}
W = np.zeros((H, NH))
wind_c = []
for i, hb in enumerate(P.HUBS):
    reg = hb["wind_region"]
    a_nat = 0.15 if reg == "west" else 0.45
    loc = ar1(NH, 0.95)
    z = a_nat * F_nat + 0.70 * F_reg[reg] + 0.55 * loc
    z = (z - z.mean()) / z.std()
    peak = 15 if reg == "west" else 230
    hpk = 16 if hb["key"] in ("PTA", "COL") else 22
    z = z + 0.30 * np.cos(2 * np.pi * (doy - peak) / 365.0) + 0.12 * np.cos(2 * np.pi * (hr - hpk) / 24.0)
    z = z + rng.normal(0, 0.08, P.YEARS)[yr]
    z = (z - z.mean()) / z.std()
    u = np.clip(norm.cdf(z), 1e-9, 1 - 1e-9)
    base = (-np.log(1 - u)) ** (1 / 2.1)

    def curve(v):
        p = np.where(v < 3.0, 0.0, np.where(v < 11.5, (v ** 3 - 27.0) / (11.5 ** 3 - 27.0), 1.0))
        return np.where(v >= 25.0, 0.0, p) * 0.90

    lo, hi = 2.0, 20.0
    for _ in range(60):
        c = 0.5 * (lo + hi)
        cf = curve(c * base).mean()
        if cf < hb["wcf"]:
            lo = c
        else:
            hi = c
    W[i] = curve(c * base)
    wind_c.append(c)

# ------------------------------------------------------------------ prices & grid availability
states = sorted(set(x["state"] for x in P.HUBS))
price = np.zeros((H, NH))
for st in states:
    idx = [i for i, x in enumerate(P.HUBS) if x["state"] == st]
    sol = PV[idx].mean(0)
    wnd = W[idx].mean(0)
    base = 85.0 if st == "WA" else 95.0
    peak = 45.0 * np.exp(-0.5 * ((hr - 18.5) / 1.6) ** 2)
    p = base + peak - 80.0 * sol - 45.0 * (wnd - wnd.mean()) + 14.0 * rng.standard_normal(NH)
    spike = (rng.random(NH) < 0.0025) & (wnd < np.quantile(wnd, 0.3))
    p = p + spike * rng.pareto(1.6, NH) * 400.0
    p = np.clip(p, -40.0, 5000.0)
    for i in idx:
        price[i] = p
aimp = np.ones((H, NH))
aexp = np.ones((H, NH))
for i, hb in enumerate(P.HUBS):
    n_ev = rng.poisson(5 * P.YEARS)
    for _ in range(n_ev):
        s = rng.integers(0, NH)
        d = rng.integers(6, 49)
        aimp[i, s:s + d] = 0.25
        aexp[i, s:s + d] = 0.25
    aexp[i] = np.minimum(aexp[i], 1.0 - 0.45 * PV[i])

# ------------------------------------------------------------------ SMR availability
SMRav = np.zeros((H, NH))
for i, hb in enumerate(P.HUBS):
    if not hb["smr"]:
        continue
    units = []
    for u_ in range(P.SMR_UNITS_PER_CANDIDATE):
        a = np.ones(NH)
        cyc = int(P.SMR_CYCLE_MONTHS / 12 * P.HPY)
        off = int(rng.integers(0, cyc)) + u_ * cyc // 2
        for s in range(-cyc, NH, cyc):
            st_ = s + off
            a[max(st_, 0):max(min(st_ + P.SMR_REFUEL_DAYS * 24, NH), 0)] = 0.0
        # forced outages: mean 72 h, FOR ~3%
        n_f = rng.poisson(P.SMR_FOR * NH / 72.0)
        for _ in range(n_f):
            s = rng.integers(0, NH)
            a[s:s + int(rng.exponential(72)) + 1] = 0.0
        units.append(a)
    SMRav[i] = np.mean(units, axis=0)

# ------------------------------------------------------------------ loads
IT = P.IT_GW * 1e3 * shares                       # MW per hub
pue = P.PUE_BASE + P.PUE_COOL_A + P.PUE_COOL_SLOPE * np.clip(T - 18.0, 0, None) \
      + P.PUE_TRIM_SLOPE * np.clip(T - 32.0, 0, None)
FAC = IT[:, None] * pue                           # MW

N_h = P.ENROLLED * shares
produce_kg = N_h * P.PRODUCE_KG
seafood_kg = N_h * P.SEAFOOD_KG
gh_area = produce_kg / P.GH_YIELD
hdd = np.clip(18.0 - T, 0, None) / 24.0           # K-day per hour
D_gh = gh_area[:, None] * P.GH_HEAT_KWH_M2_PER_HDD * hdd / 1e3                     # MWh_th/h
D_ras = seafood_kg[:, None] * P.RAS_HEAT_KWH_PER_KG_PER_K * np.clip(P.RAS_SET_T - T, 0, None) / P.HPY / 1e3
hh = N_h / P.HH_SIZE * P.HH_CONNECT
D_res = (hh[:, None] * (P.DHW_MWH_HH / P.HPY + P.SPACE_KWH_HH_PER_HDD * hdd / 1e3))
dry_t = P.COMMUNITY_DRYING_T * shares
D_dry_total = dry_t[:, None] * P.COMMUNITY_DRYING_MWH_T / P.HPY * np.ones(NH)
D_dry = D_dry_total * (1 - P.DRYER_BOOSTER_SHARE)
BOOST = D_dry_total * P.DRYER_BOOSTER_SHARE        # electric booster MW
D_dig = (P.DIGESTER_TWH * 1e6 * shares / P.HPY)[:, None] * np.ones(NH)

# seaweed
asp_t = P.FEEDLOT_CAPACITY * P.ASP_COVER_SHARE * P.ASP_G_PER_HEAD_DAY * 365 / 1e6   # t DW/y
asp_ha = asp_t / P.ASP_YIELD_T_HA
asp_alloc = {"TAR": 0.35, "CAL": 0.40, "PTA": 0.25}
kelp_hubs = ["MUS", "LAT", "PTA", "COL"]
kelp_t = P.KELP_HA_PER_SITE * len(kelp_hubs) * P.KELP_DRIED_T_HA
kelp_ha = P.KELP_HA_PER_SITE * len(kelp_hubs)
kelp_wet = kelp_t / P.KELP_DRIED_SHARE_WET
kelp_season = np.where(np.isin(month, [8, 9, 10, 11]), 1.0, 0.25)
kelp_season = kelp_season / kelp_season.mean()
D_sw = np.zeros((H, NH)); E_sw = np.zeros((H, NH))
for i, hb in enumerate(P.HUBS):
    a = asp_alloc.get(hb["key"], 0.0) * asp_t * 1e3      # kg/y
    k = (kelp_t * 1e3 / len(kelp_hubs)) if hb["key"] in kelp_hubs else 0.0
    dry = (a + k) * P.DRY_KWH_TH_PER_KG / 1e3 / P.HPY        # MWh/h average
    tank = a * P.ASP_HEAT_KWH_PER_KG / 1e3 / P.HPY if hb["key"] == "PTA" else 0.0
    kd = k * P.DRY_KWH_TH_PER_KG / 1e3 / P.HPY
    ad = a * P.DRY_KWH_TH_PER_KG / 1e3 / P.HPY
    D_sw[i] = ad + kd * kelp_season + tank
    E_sw[i] = (a * P.ASP_KWH_PER_KG + k * P.KELP_KWH_PER_KG_DRIED) / 1e3 / P.HPY
D_wat = (P.DESAL_M3 * P.DESAL_KWH_TH_M3 / 1e3 * shares / P.HPY)[:, None] * np.ones(NH)
E_wat = (P.DESAL_M3 * P.DESAL_KWH_E_M3 / 1e3 * shares / P.HPY)[:, None] * np.ones(NH)
RAS_E = (seafood_kg * P.RAS_KWH_PER_KG / 1e3 / P.HPY)[:, None] * np.ones(NH)

# heat demand stacks (MWh_th/h)
D_parts = {"residential": D_res, "greenhouse": D_gh, "aquaculture": D_ras, "drying": D_dry,
           "seaweed": D_sw, "water_treatment": D_wat, "digester": D_dig}
D_tot = sum(D_parts.values())

# mobility loads
ers_hub = np.zeros(H)
ers_rows = []
for name, km, aadt, alloc, path in P.ERS_CORRIDORS:
    e_mwh = aadt * 365 * km * P.ERS_SHARE * P.ERS_KWH_PER_KM / (1 - P.ERS_LOSS) / 1e3
    diesel_l = aadt * 365 * km * P.ERS_SHARE * P.TRUCK_L_PER_KM
    ers_rows.append(dict(corridor=name, km=km, aadt=aadt, gwh=e_mwh / 1e3, diesel_ML=diesel_l / 1e6,
                         co2_kt=diesel_l * P.DIESEL_KG_PER_L / 1e6))
    for k_, s_ in alloc.items():
        ers_hub[P.HUB_KEYS.index(k_)] += e_mwh * s_
truck_prof = 0.6 + 0.8 * np.exp(-0.5 * ((hr - 13) / 4.5) ** 2)
truck_prof = truck_prof / truck_prof.mean()
ERS = (ers_hub / P.HPY)[:, None] * truck_prof
parcels = P.ENROLLED * (P.PRODUCE_KG + P.SEAFOOD_KG) / P.DRONE_PARCEL_KG * P.DRONE_PARCEL_SHARE
deliv_drones = math.ceil(parcels / (P.DRONE_DELIV_PER_DAY * P.DRONE_DAYS))
drone_mwh = (parcels * P.DRONE_KWH_PER_DELIVERY + H * P.DRONE_INSPECT_PER_HUB * P.DRONE_INSPECT_KWH_YR
             + H * P.DRONE_AG_PER_HUB * P.DRONE_AG_KWH_YR) / 1e3
day_prof = np.where((hr >= 7) & (hr < 18), 1.0, 0.05); day_prof /= day_prof.mean()
DRONE = (drone_mwh * shares / P.HPY)[:, None] * day_prof
ev_prof = 0.4 + np.exp(-0.5 * ((hr - 12) / 3) ** 2) * 1.6; ev_prof /= ev_prof.mean()
EV = (P.EV_CHARGE_GWH * 1e3 * shares / P.HPY)[:, None] * ev_prof
MOB = ERS + DRONE + EV


def heat_case(c, k):
    cap = k * D_tot.mean(1, keepdims=True)
    deliv = np.minimum(c * D_tot, cap)
    frac = np.divide(deliv, D_tot, out=np.zeros_like(deliv), where=D_tot > 0)
    parts = {n: v * frac for n, v in D_parts.items()}
    hp_e = deliv / ((1 - P.HEAT_LOSS) * P.HP_COP)
    return deliv, parts, hp_e


HEATCASES = {"full": (1.0, 3.0), "plant1x": (1.0, 1.0), "half": (0.5, 2.0), "none": (0.0, 2.0)}
hc = {n: heat_case(*v) for n, v in HEATCASES.items()}

def load_for(case, mobility=True, flat=False):
    deliv, parts, hp_e = hc[case]
    L = FAC + BOOST + RAS_E + E_sw + E_wat + hp_e + (MOB if mobility else 0.0)
    if flat:
        L = L.mean(1, keepdims=True) * np.ones(NH)
    return L

LOADS = {"full_ext": load_for("full"), "flat_ext": load_for("full", flat=True),
         "full_core": load_for("full", mobility=False),
         "plant1x": load_for("plant1x", mobility=False), "half": load_for("half", mobility=False), "none": load_for("none", mobility=False)}
LKEYS = list(LOADS)
LSTACK = np.stack([LOADS[k] for k in LKEYS])     # (K,H,NH)

# ------------------------------------------------------------------ dispatch
def run(scen):
    """scen: list of dicts with portfolio, wind_scale, access, firm_cap_mw (or None), load key."""
    S = len(scen)
    hub_scale = shares * H
    def cap(key):
        return np.array([[P.PORTFOLIOS[s["portfolio"]][key] for _ in range(H)] for s in scen]) * hub_scale
    wcap = cap("wind") * 1e3; pcap = cap("solar") * 1e3; bE = cap("batt") * 1e3
    bP = bE / 4.0
    hvo = cap("hvo"); impc = cap("imp"); expc = cap("exp")
    smr_on = np.array([P.PORTFOLIOS[s["portfolio"]]["smr"] for s in scen])
    smr_mw = np.array([[P.SMR_UNIT_MW * P.SMR_UNITS_PER_CANDIDATE if hb["smr"] else 0.0 for hb in P.HUBS]] * S) * smr_on[:, None]
    for j, s in enumerate(scen):
        if s.get("firm_cap") is not None:
            hvo[j] = np.minimum(hvo[j], s["firm_cap"])
    wsc = np.array([s.get("wind_scale", 1.0) for s in scen])[:, None]
    acc = np.array([s.get("access", 1.0) for s in scen])[:, None]
    kidx = np.array([LKEYS.index(s["load"]) for s in scen])
    flex = (P.FLEX_SHARE * IT)[None, :] * np.ones((S, 1))
    sq = math.sqrt(P.BATT_RTE)
    budget_y = P.HVO_ANNUAL_ML * 1e6 * P.HVO_MJ_PER_L * P.HVO_ELEC_EFF / 3600.0   # MWh_e
    soc = 0.5 * bE.copy()
    acc_ = {k: np.zeros((S, H)) for k in ["uns", "imp", "exp", "hvo", "curt", "wgen", "pgen", "sgen",
                                           "load", "impcost", "exprev", "moved", "bdis"]}
    uns_t = np.zeros((S, NH), dtype=np.float32)
    tj = [j for j, s in enumerate(scen) if s.get("trace")]
    TR = {k: np.zeros((len(tj), NH), dtype=np.float32) for k in ["wind", "pv", "smr", "bdis", "bch", "hvo", "imp", "exp", "curt", "load", "uns", "moved"]}
    hvo_y = np.zeros((S, P.YEARS))
    budget = np.full(S, budget_y)
    for t in range(NH):
        if t % P.HPY == 0:
            budget[:] = budget_y
        wg = wcap * W[:, t] * wsc
        pg = pcap * PV[:, t]
        sg = smr_mw * SMRav[:, t]
        L = LSTACK[kidx, :, t]
        net = wg + pg + sg - L
        # workload migration between hubs (flexible inference share)
        shed = np.minimum(np.clip(-net, 0, None), flex)
        absb = np.minimum(np.clip(net, 0, None), flex)
        X = shed.sum(1); Y = absb.sum(1); M = np.minimum(X, Y)
        fs = np.divide(M, X, out=np.zeros(S), where=X > 0)
        fa = np.divide(M, Y, out=np.zeros(S), where=Y > 0)
        net = net + shed * fs[:, None] - absb * fa[:, None]
        # battery
        ch = np.where(net > 0, np.minimum(np.minimum(net, bP), (bE - soc) / sq), 0.0)
        soc += ch * sq; net -= ch
        dis = np.where(net < 0, np.minimum(np.minimum(-net, bP), soc * sq), 0.0)
        soc -= dis / sq; net += dis
        # export / curtail
        surplus = np.clip(net, 0, None)
        ex = np.minimum(surplus, expc * aexp[:, t] * acc)
        cu = surplus - ex
        # deficit: renewable fuel engines, then imports
        need = np.clip(-net, 0, None)
        # budget pacing: if renewable-fuel use is ahead of the annual schedule, import first
        frac_t = 1.0 - (t % P.HPY) / P.HPY
        imfirst = (budget / budget_y) < 0.9 * frac_t
        impav = impc * aimp[:, t] * acc
        im1 = np.where(imfirst[:, None], np.minimum(need, impav), 0.0)
        need -= im1
        hv = np.minimum(need, hvo)
        tot = hv.sum(1)
        scale = np.where(tot > budget, np.divide(budget, tot, out=np.zeros(S), where=tot > 0), 1.0)
        hv = hv * scale[:, None]
        budget -= hv.sum(1)
        need -= hv
        im = np.minimum(need, impav - im1) + im1
        need -= (im - im1)
        pr = price[:, t]
        acc_["uns"] += need; acc_["imp"] += im; acc_["exp"] += ex; acc_["hvo"] += hv
        acc_["curt"] += cu; acc_["wgen"] += wg; acc_["pgen"] += pg; acc_["sgen"] += sg
        acc_["load"] += L; acc_["impcost"] += im * (pr + P.NET_CHARGE_AUD_MWH); acc_["exprev"] += ex * pr
        acc_["moved"] += (shed * fs[:, None]); acc_["bdis"] += dis
        uns_t[:, t] = need.sum(1)
        if tj:
            for kk, vv in (("wind", wg), ("pv", pg), ("smr", sg), ("bdis", dis), ("bch", ch), ("hvo", hv), ("imp", im),
                           ("exp", ex), ("curt", cu), ("load", L), ("uns", need), ("moved", shed * fs[:, None])):
                TR[kk][:, t] = vv[tj].sum(1)
        hvo_y[:, t // P.HPY] += hv.sum(1)
    run.trace = TR
    return acc_, uns_t, hvo_y


def episodes(series, thr=1e-6):
    d = series > thr
    hours = int(d.sum())
    if hours == 0:
        return dict(hours=0, episodes=0, longest=0, peak_gw=0.0, h_ge1gw=0)
    dd = np.diff(np.concatenate([[0], d.astype(int), [0]]))
    starts = np.where(dd == 1)[0]; ends = np.where(dd == -1)[0]
    return dict(hours=hours, episodes=int(len(starts)), longest=int((ends - starts).max()),
                peak_gw=float(series.max() / 1e3), h_ge1gw=int((series >= 1000).sum()))


SUPPLY = [("central", {}), ("wind_minus10", {"wind_scale": 0.9}), ("half_access", {"access": 0.5}),
          ("firm_restricted", {"firm_cap": P.FIRM_RESTRICT_MW}),
          ("combined_adverse", {"wind_scale": 0.9, "access": 0.5, "firm_cap": P.FIRM_RESTRICT_MW}),
          ("central_flat_load", {})]
scen = []
for pf in ["reference", "enlarged", "enl_smr"]:
    for nm, kw in SUPPLY:
        d = dict(portfolio=pf, name=nm, load="flat_ext" if nm == "central_flat_load" else "full_ext",
                 trace=(pf in ("enlarged", "enl_smr") and nm in ("central", "combined_adverse")))
        d.update(kw); scen.append(d)
for case in ["full_core", "plant1x", "half", "none"]:
    for nm in ["central", "combined_adverse"]:
        d = dict(portfolio="enlarged", name=f"heat_{case}_{nm}", load=case)
        if nm == "combined_adverse":
            d.update({"wind_scale": 0.9, "access": 0.5, "firm_cap": P.FIRM_RESTRICT_MW})
        scen.append(d)

t0 = time.time()
ACC, UNS, HVOY = run(scen)
runtime = time.time() - t0

# ------------------------------------------------------------------ ledgers
Y = P.YEARS
def mt(x):
    return float(x)

grid_f = np.array([P.GRID_T_PER_MWH[hb["state"]] for hb in P.HUBS])
results = []
for j, s in enumerate(scen):
    a = {k: v[j] for k, v in ACC.items()}
    load_twh = a["load"].sum() / 1e6 / Y
    hvo_mwh = a["hvo"].sum() / Y
    hvo_L = hvo_mwh * 3600.0 / (P.HVO_ELEC_EFF * P.HVO_MJ_PER_L)
    pf = P.PORTFOLIOS[s["portfolio"]]
    batt_gwh = pf["batt"] * H
    c_wind = a["wgen"].sum() / Y * P.WIND_G_KWH / 1e6        # MWh * g/kWh = kg ... -> t: MWh*1e3 kWh*g/1e6 = t
    # tonnes: MWh * 1000 kWh/MWh * g/kWh / 1e6 g/t = MWh*g/1e3 ; Mt = /1e6
    c_wind = a["wgen"].sum() / Y * P.WIND_G_KWH / 1e3 / 1e6
    c_pv = a["pgen"].sum() / Y * P.PV_G_KWH / 1e3 / 1e6
    c_smr = a["sgen"].sum() / Y * P.NUC_G_KWH / 1e3 / 1e6
    c_batt = batt_gwh * 1e6 * P.BATT_KG_PER_KWH / P.BATT_LIFE / 1e9
    c_imp = float((a["imp"] / Y * grid_f).sum()) / 1e6
    c_hvo = hvo_L * P.HVO_MJ_PER_L * P.HVO_G_PER_MJ / 1e12
    uns = UNS[j].astype(np.float64)
    ep = episodes(uns)
    results.append(dict(
        portfolio=s["portfolio"], scenario=s["name"], load=s["load"],
        load_twh=load_twh, unserved_twh_16y=a["uns"].sum() / 1e6, unserved_share=a["uns"].sum() / a["load"].sum(),
        **{f"ep_{k}": v for k, v in ep.items()},
        wind_twh=a["wgen"].sum() / 1e6 / Y, pv_twh=a["pgen"].sum() / 1e6 / Y, smr_twh=a["sgen"].sum() / 1e6 / Y,
        curt_twh=a["curt"].sum() / 1e6 / Y, exp_twh=a["exp"].sum() / 1e6 / Y, imp_twh=a["imp"].sum() / 1e6 / Y,
        hvo_twh=hvo_mwh / 1e6, hvo_ML=hvo_L / 1e6, hvo_ML_max_year=float(HVOY[j].max() * 3600.0 / (P.HVO_ELEC_EFF * P.HVO_MJ_PER_L) / 1e6),
        moved_twh=a["moved"].sum() / 1e6 / Y, batt_dis_twh=a["bdis"].sum() / 1e6 / Y,
        c_wind=c_wind, c_pv=c_pv, c_smr=c_smr, c_batt=c_batt, c_imp=c_imp, c_hvo=c_hvo,
        gross=c_wind + c_pv + c_smr + c_batt + c_imp + c_hvo,
        imp_cost_m=a["impcost"].sum() / Y / 1e6, exp_rev_m=a["exprev"].sum() / Y / 1e6,
        hvo_cost_m=hvo_L * P.HVO_AUD_PER_L / 1e6,
        imp_by_hub=(a["imp"].sum(1) / Y / 1e6 if a["imp"].ndim > 1 else (a["imp"] / Y / 1e6)).tolist(),
    ))

# matched electricity services and heat credits
def twh(x):
    return float(x.sum() / 1e6 / Y)

fac_twh = twh(FAC)
boost_twh = twh(BOOST)
ras_twh = twh(RAS_E)
sw_e_twh = twh(E_sw)
wat_e_twh = twh(E_wat)
ers_twh = twh(ERS); drone_twh = twh(DRONE); ev_twh = twh(EV)
heat_tab = {}
gas_share = np.array([hb["gas_heat_share"] for hb in P.HUBS])
for n, (deliv, parts, hp_e) in hc.items():
    res = parts["residential"].sum(1) / Y        # MWh_th/y per hub
    dry = parts["drying"].sum(1) / Y
    gas_GJ = (res * gas_share / P.RES_HEAT_GAS_BOILER_EFF + dry / P.DRY_GAS_EFF) * 3.6
    credit_gas = gas_GJ * P.GAS_KG_PER_GJ / 1e9                       # Mt
    credit_el = (res * (1 - gas_share) * grid_f).sum() / 1e6          # resistive heating displaced, Mt
    heat_tab[n] = dict(
        delivered_twh=twh(deliv), demand_twh=twh(D_tot), hp_twh=twh(hp_e),
        parts={k: twh(v) for k, v in parts.items()},
        credit_mt=float(credit_gas.sum() + credit_el),
        credit_gas_mt=float(credit_gas.sum()), credit_el_mt=float(credit_el),
        res_twh=float(res.sum() / 1e6), dry_twh=float(dry.sum() / 1e6),
        core_service_twh=fac_twh + boost_twh + ras_twh + sw_e_twh + wat_e_twh + twh(hp_e),
        ext_service_twh=fac_twh + boost_twh + ras_twh + sw_e_twh + wat_e_twh + twh(hp_e) + ers_twh + drone_twh + ev_twh)

ers_diesel_L = sum(r["diesel_ML"] for r in ers_rows) * 1e6
ers_credit = ers_diesel_L * P.DIESEL_KG_PER_L / 1e9
van_L = parcels * P.VAN_KM_PER_DELIVERY * P.VAN_L_PER_KM
drone_credit = van_L * P.DIESEL_KG_PER_L / 1e9


def gas_case(E_twh, capture=0.0, leak=P.LEAK, penalty=None, eff=P.CCGT_EFF_HHV):
    pen = P.CCS_PENALTY if (capture > 0 and penalty is None) else (penalty or 0.0)
    fuel_GJ = E_twh * 3.6e6 / eff * (1 + pen)
    co2 = fuel_GJ * P.GAS_KG_PER_GJ * (1 - capture) / 1e9
    ch4 = fuel_GJ * P.CH4_KG_PER_GJ * leak / (1 - leak) * P.GWP_CH4 / 1e9
    return dict(fuel_twh=fuel_GJ / 3.6e6, co2=co2, ch4=ch4, total=co2 + ch4,
                nonelec_twh=fuel_GJ / 3.6e6 - E_twh)

E_core = heat_tab["full"]["core_service_twh"]
E_ext = heat_tab["full"]["ext_service_twh"]
gas = {}
for lab, E in [("facility", fac_twh), ("facility_boost", fac_twh + boost_twh), ("core", E_core), ("ext", E_ext)]:
    gas[lab] = {c: gas_case(E, capture=c) for c in [0.0, 0.90, 0.95]}

out = dict(runtime_s=runtime, scenarios=results, heat=heat_tab, gas=gas,
           fac_twh=fac_twh, boost_twh=boost_twh, ras_twh=ras_twh, sw_e_twh=sw_e_twh, wat_e_twh=wat_e_twh,
           ers_twh=ers_twh, drone_twh=drone_twh, ev_twh=ev_twh, E_core=E_core, E_ext=E_ext,
           pue_mean=float((FAC.sum()) / (IT.sum() * NH)), pue_hub=(FAC.mean(1) / IT).tolist(),
           pue_max=float(pue.max()), hours_T_gt35=[int((T[i] > 35).sum() / Y) for i in range(H)],
           T_mean=T.mean(1).tolist(), T_max=T.max(1).tolist(), T_min=T.min(1).tolist(),
           wind_cf=W.mean(1).tolist(), pv_cf=PV.mean(1).tolist(), wind_c=wind_c, pv_ratio=pv_ratio,
           wind_cf_year_min=[float(W[i].reshape(Y, -1).mean(1).min()) for i in range(H)],
           wind_cf_year_max=[float(W[i].reshape(Y, -1).mean(1).max()) for i in range(H)],
           pv_cf_year_min=[float(PV[i].reshape(Y, -1).mean(1).min()) for i in range(H)],
           pv_cf_year_max=[float(PV[i].reshape(Y, -1).mean(1).max()) for i in range(H)],
           wind_corr=np.corrcoef(W).tolist(), price_mean=price.mean(1).tolist(),
           smr_avail=[float(SMRav[i].mean()) for i in range(H)],
           IT_mw=IT.tolist(), enrolled=P.ENROLLED, N_h=N_h.tolist(),
           produce_t=float(produce_kg.sum() / 1e3), seafood_t=float(seafood_kg.sum() / 1e3),
           gh_ha=float(gh_area.sum() / 1e4), feed_t=float(seafood_kg.sum() / 1e3 * P.FCR),
           asp_t=asp_t, asp_ha=asp_ha, kelp_t=kelp_t, kelp_ha=kelp_ha, kelp_wet_t=kelp_wet,
           asp_ch4_abate_mt=P.FEEDLOT_CAPACITY * P.ASP_COVER_SHARE * P.CH4_KG_HEAD_YR * P.ASP_CH4_CUT * P.GWP_CH4 / 1e9,
           asp_head=P.FEEDLOT_CAPACITY * P.ASP_COVER_SHARE,
           kelp_co2_kt=kelp_wet * P.KELP_KG_CO2E_PER_T_FRESH / 1e6, kelp_N_t=kelp_t * (1 - 0.185) * P.KELP_N_KG_PER_T_DW / 1e3,
           ers=ers_rows, ers_credit_mt=ers_credit, ers_diesel_ML=ers_diesel_L / 1e6,
           ers_km=sum(r["km"] for r in ers_rows),
           parcels=parcels, deliv_drones=deliv_drones,
           drones_total=deliv_drones + H * (P.DRONE_INSPECT_PER_HUB + P.DRONE_AG_PER_HUB),
           drone_credit_mt=drone_credit, van_L=van_L,
           ers_hub_gwh=(ers_hub / 1e3).tolist())
with open(os.path.join(HERE, "dga_results_synthetic.json"), "w") as f:
    json.dump(out, f, indent=1, default=float)
np.savez_compressed(os.path.join(HERE, "dga_trace_synthetic.npz"), **{k: v for k, v in run.trace.items()},
                    names=np.array([f"{s['portfolio']}|{s['name']}" for s in scen if s.get("trace")]))
np.savez_compressed(os.path.join(HERE, "dga_hourly_synthetic.npz"), UNS=UNS, W=W.astype(np.float32), PV=PV.astype(np.float32),
                    T=T.astype(np.float32), D_tot=D_tot.astype(np.float32), FAC=FAC.astype(np.float32),
                    LOAD=LOADS["full_ext"].astype(np.float32), SMRav=SMRav.astype(np.float32),
                    price=price.astype(np.float32))
print("runtime", runtime)
for r in results:
    print(f"{r['portfolio']:9s} {r['scenario']:28s} load {r['load_twh']:6.2f} uns16 {r['unserved_twh_16y']:8.3f} "
          f"peak {r['ep_peak_gw']:5.2f} hrs {r['ep_hours']:6d} imp {r['imp_twh']:5.2f} hvoML {r['hvo_ML']:6.0f} "
          f"exp {r['exp_twh']:5.2f} curt {r['curt_twh']:5.2f} gross {r['gross']:5.3f} moved {r['moved_twh']:4.2f}")
